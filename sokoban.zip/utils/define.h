//
// Created by jh_svt on 19. 5. 26.
//

#ifndef SOKOBAN_DEFINE_H
#define SOKOBAN_DEFINE_H

#define IN const

#endif //SOKOBAN_DEFINE_H
