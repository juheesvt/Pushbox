//
// Created by jh_svt on 19. 5. 26.
//

#ifndef SOKOBAN_BOX_H
#define SOKOBAN_BOX_H


class Box {

};


#endif //SOKOBAN_BOX_H
