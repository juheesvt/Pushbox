//
// Created by jh_svt on 19. 5. 26.
//

#ifndef SOKOBAN_GOAL_H
#define SOKOBAN_GOAL_H


class Goal {

};


#endif //SOKOBAN_GOAL_H
