//
// Created by jh_svt on 19. 5. 26.
//

#ifndef SOKOBAN_USER_H
#define SOKOBAN_USER_H


class User {
public:
private:
};


#endif //SOKOBAN_USER_H
