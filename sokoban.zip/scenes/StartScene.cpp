//
// Created by jh_svt on 19. 5. 23.
//

#include "StartScene.h"
StartScene::StartScene(int x, int y, int width, int height):Pane(x,y,width,height) {
	//bkgd(COLOR_PAIR(1));
    this->startData=new FileManager("datas/startscene.dat"); // 파 일경 로알아보
    this->menuPane = new MenuPane(4,7,17,7);
	wbkgd(pWindow, COLOR_PAIR(1));
}
StartScene::~StartScene() {
    delete this->menuPane;
    delete this->startData;
    delwin(this->pWindow);
}
void StartScene::render() {
    attron(COLOR_PAIR(2));

	for (int row = 0; row < this->startData->getLineLength(); ++row) {
		mvwprintw(this->getWindow(), row, 0, this->startData->getLine(row).c_str());      // c_str : string -> char *
	}
	wrefresh(this->getWindow());

    this->menuPane->render();

    attroff(COLOR_PAIR(2));

}
void StartScene::update(IN int key){
    this->menuPane->update(key);
}