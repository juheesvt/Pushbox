//
// Created by jh_svt on 19. 5. 26.
//

#ifndef SOKOBAN_GAMESCENE_H
#define SOKOBAN_GAMESCENE_H


class GameScene {

};


#endif //SOKOBAN_GAMESCENE_H
