#include "managers/SceneManager.h"
#include "scenes/StartScene.h"
void init();
int main() {

	SceneManager * sceneManager = new SceneManager();
	StartScene * startScene = new StartScene(0,0,70,20);

	// 현재 윈도우를 startScene으로 설정하고 render()함수를 통해 보여주
	sceneManager->setNowScene(startScene);
	sceneManager->render();
		
	while (true) {
		int key = 0;
		keypad(stdscr, true);
		key = getch();
		sceneManager->update(key);
		sceneManager->render();
	}
	
	endwin();
	return 0;
}
void init() {
	initscr();
	start_color();
	init_pair(1, COLOR_BLACK, COLOR_YELLOW);
	init_pair(2, COLOR_RED, COLOR_GREEN);
	init_pair(3, COLOR_BLACK, COLOR_BLACK);
	init_pair(4, COLOR_CYAN, COLOR_CYAN);
	init_pair(5, COLOR_BLUE, COLOR_BLUE);
	curs_set(0);
	cbreak();
	noecho();
	nodelay(stdscr, TRUE);
	scrollok(stdscr, TRUE);

	refresh();
}